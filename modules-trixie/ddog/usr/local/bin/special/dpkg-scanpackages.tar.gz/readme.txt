Hi All, Here's little howto for creating a local repo. For example from the .deb packages downloaded from here: http://www.smokey01.com/saintless/Fredx181/ There's lots of info on the net but some of them suggests to use apache2 which we're not going to use here. The script "dpkg-scanpackages" can create a local database from a folder with .deb files inside. dpkg-scanpackages is part of "dpkg-dev" package but to install it, with all dependencies, it needs to much space for DebianDog. So we need only "dpkg-scanpackages" and to load the DEVX Attached: dpkg-scanpackages.zip Extract and place the script "dpkg-scanpackages" somewhere in PATH e.g. /opt/bin Download "06-DEVX-DebDog-2.squashfs" module, from here: http://www.smokey01.com/saintless/DebianDog/System-modules (right-click > save link as) Then use SFS-loader to load it, or: from terminal opened in folder where you downloaded "06-DEVX-DebDog-2.squashfs":
Code:
loadmodule -a 06-DEVX-DebDog-2.squashfs


Let's take as example: a folder created on /media/sda1 named "myrepo": (/media/sda1 must be a linux filesystem like ext3 or ext4)
Code:
mkdir /media/sda1/myrepo

Then copy all .deb files you want included in your local database to: /media/sda1/myrepo Then in terminal:
Code:
cd  /media/sda1/myrepo dpkg-scanpackages ./ /dev/null |gzip > Packages.gz

Then open /etc/apt/sources.list with geany:
Code:
geany /etc/apt/sources.list

And add to it on a single line:
Code:
deb file://media/sda1/myrepo/ ./

Save the file. Then update database:
Code:
apt-get update

Now you can install/uninstall all packages in /media/sda1/myrepo by using apt-get or synaptic. When you remove or add .deb files in /media/sda1/myrepo you need to update the database again by loading the "06-DEVX-DebDog-2.squashfs" and doing the previous commands again:
Code:
cd  /media/sda1/myrepo dpkg-scanpackages ./ /dev/null |gzip > Packages.gz


Fred
